Relatório Detalhado: Análise do
FlowBuilder e Integração com OpenAI no
Projeto Multizap
1. Introdução
Este relatório tem como objetivo detalhar o funcionamento do módulo FlowBuilder
presente no projeto Multizap, com foco especial em sua integração com a tecnologia
OpenAI. Serão abordados aspectos da arquitetura do projeto, a lógica de construção e
gerenciamento de fluxos no frontend e backend, e a implementação da comunicação
com a API da OpenAI.
O projeto Multizap parece ser uma plataforma de comunicação que permite a
automação de interações com usuários, provavelmente via WhatsApp ou outras
plataformas de mensagens. O FlowBuilder é uma ferramenta crucial dentro deste
ecossistema, permitindo que os usuários criem fluxos de conversação complexos e
personalizados sem a necessidade de programação, utilizando uma interface visual de
arrastar e soltar. A integração com a OpenAI adiciona uma camada de inteligência
artificial, possibilitando respostas mais dinâmicas e contextuais nos fluxos.
2. Estrutura do Projeto Multizap
O projeto Multizap é dividido em duas partes principais: frontend e backend . Ambos os
componentes são desenvolvidos em TypeScript, utilizando frameworks e bibliotecas
modernas para suas respectivas finalidades.
2.1. Frontend
O frontend é construído com React, uma biblioteca JavaScript para construção de
interfaces de usuário. A estrutura de diretórios revela uma organização modular, com
componentes reutilizáveis ( components ), páginas ( pages ), serviços ( services ), e rotas
( routes ).
src/pages/FlowBuilderConfig/index.js : Este é o arquivo central para a interface
do FlowBuilder. Ele gerencia o estado dos nós (nodes) e arestas (edges) do fluxo,
lida com a interação do usuário (cliques, arrastar e soltar), e integra os diferentes
tipos de nós, incluindo o nó de OpenAI ( openaiNode ). Utiliza a biblioteca reactflow-renderer para a renderização visual do fluxo.
src/components/FlowBuilderAddOpenAIModal/index.js : Este componente é um
modal (janela pop-up) que permite ao usuário configurar as opções de um nó de
OpenAI dentro do FlowBuilder. Ele coleta informações como nome, prompt, chave
de API, configurações de voz (para texto-para-voz), temperatura e limites de
mensagens, que são essenciais para a interação com a API da OpenAI.
src/pages/FlowBuilderConfig/nodes/openaiNode.js : Define a representação
visual e o comportamento de um nó de OpenAI no FlowBuilder. Ele exibe um ícone
da OpenAI e um rótulo, e permite a conexão com outros nós do fluxo.
src/services/api.js : Responsável pela comunicação com o backend, enviando
e recebendo dados relacionados aos fluxos do FlowBuilder, incluindo as
configurações dos nós.
2.2. Backend
O backend é desenvolvido em Node.js, utilizando TypeScript e o framework Express
(implícito pela estrutura de serviços e controladores). Ele é responsável pela lógica de
negócio, persistência de dados e integração com serviços externos, como a OpenAI.
src/models/FlowBuilder.ts : Define o modelo de dados para o FlowBuilder no
banco de dados. Ele armazena informações como user_id , name , company_id ,
active , e, crucialmente, o flow (estrutura do fluxo em JSON) e variables
(variáveis associadas ao fluxo, também em JSON). A persistência é feita utilizando
sequelize-typescript , indicando o uso de um banco de dados relacional
(provavelmente PostgreSQL ou MySQL).
src/services/IntegrationsServices/OpenAiService.ts : Este serviço é o ponto
principal de interação com a API da OpenAI. Ele gerencia as sessões da OpenAI,
envia requisições para o chat.completions (para geração de texto) e
audio.transcriptions (para transcrição de áudio), e lida com a chave de API da
OpenAI. Ele também parece ter funcionalidades para converter texto em fala
( convertTextToSpeechAndSaveToFile ).
src/services/MessageServices/TranscribeAudioMessageService.ts : Este
serviço parece ser responsável por transcrever mensagens de áudio utilizando a
API da OpenAI. Ele busca a chave de API da OpenAI nas configurações do sistema
( openaikeyaudio ) e faz uma requisição POST para o endpoint de transcrição de
áudio da OpenAI.
src/services/WbotServices/wbotMessageListener.ts : Este arquivo é um
ouvinte de mensagens do WhatsApp (provavelmente usando a biblioteca Baileys,
dado o WASocket importado). Ele é responsável por processar as mensagens
recebidas e, em certos casos, interagir com o FlowBuilder e os serviços da OpenAI
para gerar respostas automáticas ou transcrever áudios.
src/services/WebhookService/ActionsWebhookService.ts : Este serviço lida
com ações de webhook e parece ter lógica para verificar se um nó do tipo "openai"
foi acionado, indicando que uma interação com a OpenAI deve ocorrer.
3. Lógica e Funcionamento do FlowBuilder
O FlowBuilder é uma ferramenta visual que permite a criação de fluxos de conversação.
Sua lógica central reside na manipulação de nós (nodes) e arestas (edges), que
representam os passos do fluxo e as transições entre eles, respectivamente.
3.1. Representação do Fluxo
No frontend, o fluxo é visualizado e manipulado através da biblioteca react-flowrenderer . Cada elemento do fluxo é um node com um id único, uma position
(coordenadas x e y na tela), data (informações específicas do nó, como texto, URL,
configurações da OpenAI, etc.) e um type (que define o tipo de nó, como message ,
interval , menu , img , audio , randomizer , video , singleBlock , ticket , typebot ,
openai , question , e start ).
As conexões entre os nós são representadas por edges , que ligam um source (nó de
origem) a um target (nó de destino). Essas arestas podem ter type s específicos, como
buttonedge , que provavelmente representa uma transição baseada na escolha de um
botão pelo usuário.
No backend, a estrutura do fluxo é armazenada no banco de dados como um objeto
JSON dentro do modelo FlowBuilderModel . Este objeto contém arrays de nodes e
connections (arestas), espelhando a estrutura do frontend. Isso permite que o fluxo
seja salvo, carregado e editado de forma persistente.
3.2. Criação e Edição de Fluxos
A interface do FlowBuilder ( FlowBuilderConfig/index.js ) permite ao usuário:
Adicionar Nós: Através de um SpeedDial (menu de ações rápidas), o usuário pode
selecionar diferentes tipos de nós para adicionar ao fluxo. A função addNode é
responsável por criar um novo nó com um id aleatório, posicioná-lo na tela e
adicionar os dados específicos do tipo de nó.
Conectar Nós: O onConnect callback do react-flow-renderer é utilizado para
criar arestas entre os nós, definindo as transições do fluxo.
Editar Nós: Um clique duplo em um nó abre um modal específico para edição
( FlowBuilderAddOpenAIModal para nós de OpenAI, por exemplo). Esses modais
permitem que o usuário modifique os dados associados ao nó. A função
updateNode é responsável por atualizar os dados do nó no estado do React Flow.
Salvar Fluxo: A função saveFlow envia a estrutura atual dos nós e arestas para o
backend através de uma requisição POST para /flowbuilder/flow . O backend
então persiste essa estrutura no banco de dados.
3.3. Execução do Fluxo
A execução do fluxo ocorre principalmente no backend, através do serviço
wbotMessageListener.ts . Quando uma nova mensagem é recebida (provavelmente de
um usuário final), este serviço verifica o FlowBuilderModel associado ao ticket
(conversa) para determinar qual fluxo está ativo. Ele então navega através dos nós do
fluxo com base nas interações do usuário e na lógica definida em cada nó.
Por exemplo, se o fluxo encontrar um nó do tipo openai , o wbotMessageListener.ts
acionará o OpenAiService.ts para interagir com a API da OpenAI. Se for um nó de
menu , ele apresentará opções ao usuário e aguardará uma resposta para seguir o
caminho apropriado. O FlowBuilderModel também armazena variables , que podem
ser usadas para personalizar as interações do fluxo com base em dados coletados do
usuário ou de outras fontes.
4. Integração com OpenAI
A integração com a OpenAI é um dos pontos chave do FlowBuilder, permitindo que os
fluxos de conversação incorporem capacidades de inteligência artificial, como geração
de texto e transcrição de áudio. Essa integração é cuidadosamente orquestrada entre o
frontend e o backend.
4.1. Configuração no Frontend
No frontend, a configuração da integração com a OpenAI é realizada através do
componente FlowBuilderAddOpenAIModal
( frontend/src/components/FlowBuilderAddOpenAIModal/index.js ). Este modal
permite ao usuário definir os seguintes parâmetros para um nó de OpenAI:
Nome: Um identificador para o nó.
Prompt: A instrução ou contexto inicial que será enviado à API da OpenAI para
gerar uma resposta. Este é um campo crucial para guiar o comportamento da IA.
Chave de API ( apiKey ): A chave de autenticação para acessar os serviços da
OpenAI. É importante que esta chave seja tratada com segurança e não seja
exposta no frontend.
Voz ( voice , voiceKey , voiceRegion ): Estas configurações sugerem a capacidade
de utilizar serviços de texto-para-voz (TTS) para as respostas da OpenAI. O campo
voice oferece uma lista de vozes pré-definidas (como Francisca, Antônio, Brenda,
etc.), enquanto voiceKey e voiceRegion podem ser usados para configurações
mais avançadas ou para integração com serviços de TTS específicos (como Azure
Cognitive Services, que utiliza chaves e regiões para suas vozes neurais).
Temperatura ( temperature ): Um parâmetro que controla a aleatoriedade das
respostas da OpenAI. Valores mais altos (próximos de 1) tornam as respostas mais
criativas e variadas, enquanto valores mais baixos (próximos de 0) as tornam mais
focadas e determinísticas.
Máximo de Tokens ( maxTokens ): O número máximo de tokens (palavras ou partes
de palavras) que a OpenAI deve gerar na resposta. Isso ajuda a controlar o tamanho
da saída e os custos associados.
Máximo de Mensagens ( maxMessages ): Provavelmente, o número máximo de
mensagens do histórico da conversa que serão enviadas à OpenAI para manter o
contexto. Isso é fundamental para conversas coerentes e contínuas.
Esses parâmetros são armazenados no objeto data do nó de OpenAI no frontend e,
posteriormente, persistidos no backend como parte da estrutura do fluxo.
4.2. Processamento no Backend
O backend é o responsável por intermediar a comunicação com a API da OpenAI,
garantindo a segurança da chave de API e o processamento adequado das requisições.
Os principais componentes envolvidos são:
OpenAiService.ts
( backend/src/services/IntegrationsServices/OpenAiService.ts ): Este serviço
é o coração da integração. Ele utiliza a biblioteca oficial openai para Node.js. As
funcionalidades incluem:
Gerenciamento de Sessões: O serviço mantém um array sessionsOpenAi
para gerenciar múltiplas instâncias da API da OpenAI, possivelmente uma por
ticket ou whatsappId , o que pode otimizar o uso e o contexto das
conversas.
Criação de Instância OpenAI: Uma nova instância da OpenAI é criada com a
apiKey fornecida nas configurações do nó. Isso garante que cada interação
com a OpenAI seja autenticada corretamente.
Geração de Texto ( chat.completions.create ): Quando um nó de OpenAI é
ativado no fluxo, o serviço chama o endpoint chat.completions.create da
API da OpenAI. Ele envia o prompt configurado no frontend, juntamente com
o histórico da conversa (para manter o contexto) e os parâmetros de
temperature e maxTokens . A resposta da OpenAI (o texto gerado) é então
utilizada para continuar a conversa no fluxo.
Transcrição de Áudio ( audio.transcriptions.create ): O serviço também
possui a capacidade de transcrever áudios. Isso é evidenciado pela chamada
a openai.audio.transcriptions.create . Isso é complementado pelo
TranscribeAudioMessageService.ts .
Texto para Fala: A presença de configurações de voice , voiceKey e
voiceRegion no frontend, juntamente com a função
convertTextToSpeechAndSaveToFile no wbotMessageListener.ts (que
provavelmente é chamada pelo OpenAiService ou um serviço relacionado),
indica que o sistema pode converter as respostas de texto da OpenAI em
áudio, proporcionando uma experiência mais rica ao usuário.
TranscribeAudioMessageService.ts
( backend/src/services/MessageServices/TranscribeAudioMessageService.ts ):
Este serviço é especificamente dedicado à transcrição de mensagens de áudio. Ele
busca a chave de API da OpenAI ( openaikeyaudio ) no banco de dados (através do
modelo Setting ) e faz uma requisição POST direta para
https://api.openai.com/v1/audio/transcriptions . Isso sugere que a
transcrição de áudio pode ser um processo separado da geração de texto principal,
mas ambos utilizam a mesma infraestrutura da OpenAI.
wbotMessageListener.ts
( backend/src/services/WbotServices/wbotMessageListener.ts ): Este ouvinte
de mensagens atua como o orquestrador. Ele identifica quando uma mensagem
deve ser processada por um nó de OpenAI no FlowBuilder e, em seguida, invoca o
OpenAiService para obter a resposta da IA. Ele também é responsável por lidar
com a transcrição de áudio antes de passar o texto para o FlowBuilder ou para o
OpenAiService para processamento.
4.3. Lógica de Interação
A lógica de interação entre o FlowBuilder e a OpenAI segue os seguintes passos:
1. Definição do Nó OpenAI: O usuário cria um nó do tipo 'openai' no FlowBuilder e
configura seus parâmetros (prompt, API Key, etc.) através do modal no frontend.
2. Persistência do Fluxo: O fluxo, incluindo as configurações do nó OpenAI, é salvo no
backend e armazenado no banco de dados ( FlowBuilderModel ).
3. Mensagem do Usuário: Um usuário final envia uma mensagem que, de acordo
com a lógica do fluxo, ativa o nó de OpenAI.
4. Ativação do Serviço OpenAI: O wbotMessageListener.ts detecta a ativação do
nó OpenAI e invoca o OpenAiService.ts .
5. Requisição à OpenAI: O OpenAiService.ts constrói a requisição para a API da
OpenAI, incluindo o prompt, o histórico da conversa e os parâmetros configurados.
A chave de API é utilizada de forma segura no backend.
6. Resposta da OpenAI: A API da OpenAI processa a requisição e retorna uma
resposta de texto (ou áudio, se a transcrição for solicitada).
7. Continuação do Fluxo: A resposta da OpenAI é então utilizada pelo
wbotMessageListener.ts para continuar o fluxo de conversação, seja enviando a
resposta ao usuário, direcionando para outro nó, ou armazenando informações.
Essa arquitetura modular e a separação de responsabilidades entre frontend e backend
garantem que a integração com a OpenAI seja robusta, segura e escalável, permitindo
que o FlowBuilder ofereça experiências de conversação inteligentes e dinâmicas.
5. Conclusão
O FlowBuilder do projeto Multizap é uma ferramenta poderosa e bem estruturada para a
criação de fluxos de conversação automatizados. Sua arquitetura, dividida em frontend
e backend, permite uma clara separação de responsabilidades e facilita a manutenção e
escalabilidade do sistema.
A integração com a OpenAI é um diferencial significativo, adicionando inteligência
artificial aos fluxos de conversação. A capacidade de configurar prompts, chaves de API,
e parâmetros como temperatura e máximo de tokens diretamente na interface do
FlowBuilder oferece grande flexibilidade aos usuários para personalizar as interações
com a IA. A funcionalidade de texto-para-voz e transcrição de áudio complementa essa
integração, tornando as conversas mais naturais e acessíveis.
Em resumo, o FlowBuilder, em conjunto com a integração OpenAI, transforma o Multizap
em uma plataforma robusta para automação de atendimento, capaz de oferecer
experiências de usuário ricas e inteligentes através de fluxos de conversação dinâmicos e
adaptáveis.
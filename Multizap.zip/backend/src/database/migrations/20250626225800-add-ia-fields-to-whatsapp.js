'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.addColumn('Whatsapps', 'geminiApiKey', {
        type: Sequelize.TEXT,
        allowNull: true
      }),
      queryInterface.addColumn('Whatsapps', 'ollamaUrl', {
        type: Sequelize.TEXT,
        allowNull: true
      }),
      queryInterface.addColumn('Whatsapps', 'ollamaModel', {
        type: Sequelize.TEXT,
        allowNull: true
      }),
      queryInterface.addColumn('Whatsapps', 'ollamaPrompt', {
        type: Sequelize.TEXT,
        allowNull: true
      }),
      queryInterface.addColumn('Whatsapps', 'iaBot', {
        type: Sequelize.BOOLEAN,
        allowNull: false,
        defaultValue: false
      })
    ]);
  },

  down: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.removeColumn('Whatsapps', 'geminiApiKey'),
      queryInterface.removeColumn('Whatsapps', 'ollamaUrl'),
      queryInterface.removeColumn('Whatsapps', 'ollamaModel'),
      queryInterface.removeColumn('Whatsapps', 'ollamaPrompt'),
      queryInterface.removeColumn('Whatsapps', 'iaBot')
    ]);
  }
};

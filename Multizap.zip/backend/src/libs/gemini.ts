import { GoogleGenerativeAI } from "@google/generative-ai";

export const getGoogleGenerativeAI = (apiKey: string) => {
  return new GoogleGenerativeAI(apiKey);
};
